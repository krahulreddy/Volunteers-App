package com.example.hemanthreddy.navigation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class forgot_password extends AppCompatActivity {

    Intent Newpage;
    private int flag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);


        Button forgot =(Button)findViewById(R.id.reset);
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag=0;
                Newpage = new Intent(forgot_password.this, login.class);

                TextView confirmpassword = (TextView) findViewById(R.id.confirmpassword);
                String A = confirmpassword.getText().toString();

                TextView password = (TextView) findViewById(R.id.newpassword);
                String B = password.getText().toString();

                if (TextUtils.isEmpty(A)) {
                    confirmpassword.setError("Retype password");
                    flag=1;
                }
                if(TextUtils.isEmpty(B)) {
                    password.setError("Enter new password");
                    flag=1;
                }
                if(flag==0) {
                    if (A.equals(B)) {
                        startActivity(Newpage);
                        Toast.makeText(forgot_password.this, "Password Changed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(forgot_password.this, "Password Not matched", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
