package com.exampledemo.parsaniahardik.searchviewdemonuts;

public class EventNames {
    private String movieName;

    public EventNames(String movieName) {
        this.movieName = movieName;
    }

    public String getAnimalName() {
        return this.movieName;
    }

}