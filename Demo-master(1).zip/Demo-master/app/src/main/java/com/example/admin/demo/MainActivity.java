package com.example.admin.demo;

import android.content.Intent;
import android.support.v4.text.TextUtilsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.text.TextUtils.isEmpty;

public class MainActivity extends AppCompatActivity {
    private int flag=0;
    private String input;
    private String password;
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final EditText Username=(EditText)findViewById(R.id.username);
       final EditText Password=(EditText)findViewById(R.id.password);
        Button Login=(Button)findViewById(R.id.login) ;
        TextView forgotpassword=(TextView)findViewById(R.id.forgotpassword);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag=0;
                input=Username.getText().toString();
                password=Password.getText().toString();
                if (TextUtils.isEmpty(input)) {
                    Username.setError("Enter Username");
                    flag=1;
                }
                if(TextUtils.isEmpty(password)) {
                    Password.setError("Enter Password");
                    flag=1;
                }

                if(flag==0)
                {
                    Toast.makeText(MainActivity.this,"Welcome",Toast.LENGTH_SHORT).show();
                }
            }
        });

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent=new Intent(MainActivity.this,ForgotPassword.class);
                startActivity(intent);
            }
        });

    }


}
